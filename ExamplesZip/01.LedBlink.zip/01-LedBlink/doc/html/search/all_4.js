var searchData=
[
  ['iocondisable_30',['IOCONDisable',['../GPIO__FW_8c.html#a96df0d2a579725fdd690ac60f5d84e97',1,'IOCONDisable(void):&#160;GPIO_FW.c'],['../GPIO__FW_8h.html#a22d5bf787f7803f0a49b2458d9ec6a69',1,'IOCONDisable(void):&#160;GPIO_FW.c']]],
  ['ioconenable_31',['IOCONEnable',['../GPIO__FW_8c.html#a0987063ef237f649ca0516b95713e177',1,'IOCONEnable(void):&#160;GPIO_FW.c'],['../GPIO__FW_8h.html#a976cfc82607589bc84880c2a45f4eab4',1,'IOCONEnable(void):&#160;GPIO_FW.c']]]
];
