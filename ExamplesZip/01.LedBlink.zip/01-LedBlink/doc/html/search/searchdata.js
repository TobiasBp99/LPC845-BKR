var indexSectionsWithContent =
{
  0: "0abgilmstu",
  1: "0agms",
  2: "bgilms",
  3: "t",
  4: "u",
  5: "blu"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "enumvalues",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Enumerator",
  5: "Macros"
};

